const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;

// ============================================================
// PASSWORD - CHANGE THIS IF YOU WANT
// Copy this password and save it somewhere safe (your notepad)
// ============================================================
const DASHBOARD_PASSWORD = 'BnRe3pZhNvhjqMvEZCWsUOkAHzxc8Yhs8cLacgfz0tCrNE1thvxdzoxG8ZaOM4AungPdJ8ZfAyYyEtdOO3KQEPd4U69SbVf2qafC';
// ============================================================

const DATA_DIR = path.join(__dirname, 'data');
const SCRIPTS_FILE = path.join(DATA_DIR, 'scripts.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Load scripts from disk (or start empty)
function loadScripts() {
  try {
    if (fs.existsSync(SCRIPTS_FILE)) {
      return JSON.parse(fs.readFileSync(SCRIPTS_FILE, 'utf8'));
    }
  } catch (e) {
    console.error('Failed to load scripts.json:', e.message);
  }
  return {};
}

function saveScripts(scripts) {
  fs.writeFileSync(SCRIPTS_FILE, JSON.stringify(scripts, null, 2), 'utf8');
}

let scripts = loadScripts();

// Middleware
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: DASHBOARD_PASSWORD + '-session-secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
  }
}));

// Serve static files only after auth check for most routes
app.use('/static', express.static(path.join(__dirname, 'public')));

// Auth helper
function requireAuth(req, res, next) {
  if (req.session && req.session.authenticated) {
    return next();
  }
  // For API calls return 401, for pages redirect or 404
  if (req.path.startsWith('/api/')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  return res.status(404).send('Not Found');
}

// ===================== PUBLIC RAW ENDPOINTS =====================
// These are intentionally public (the URL itself is the secret)
// Returns pure text/plain so loadstring(game:HttpGet(...)) works

app.get('/raw/:name', (req, res) => {
  const name = (req.params.name || '').toLowerCase().replace(/[^a-z0-9\-_]/g, '');
  if (!name || !scripts[name]) {
    return res.status(404).type('text/plain').send('404 Not Found');
  }

  const script = scripts[name];
  res.set({
    'Content-Type': 'text/plain; charset=utf-8',
    'Cache-Control': 'no-store, no-cache, must-revalidate',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.send(script.content);
});

// Also support /raw/:name.lua for convenience
app.get('/raw/:name.lua', (req, res) => {
  req.url = `/raw/${req.params.name}`;
  app._router.handle(req, res);
});

// CORS preflight
app.options('/raw/:name', (req, res) => {
  res.set({
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.sendStatus(204);
});

// ===================== LOGIN =====================

app.get('/login', (req, res) => {
  if (req.session && req.session.authenticated) {
    return res.redirect('/');
  }
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.post('/login', (req, res) => {
  const { password } = req.body;
  if (password === DASHBOARD_PASSWORD) {
    req.session.authenticated = true;
    return res.json({ success: true });
  }
  return res.status(401).json({ error: 'Invalid password' });
});

app.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.json({ success: true });
  });
});

// ===================== PROTECTED DASHBOARD =====================

app.get('/', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// List all scripts
app.get('/api/scripts', requireAuth, (req, res) => {
  const list = Object.keys(scripts).map(name => ({
    name,
    size: scripts[name].content.length,
    updated: scripts[name].updated,
    id: scripts[name].id
  }));
  res.json(list);
});

// Get one script content
app.get('/api/scripts/:name', requireAuth, (req, res) => {
  const name = req.params.name.toLowerCase();
  if (!scripts[name]) {
    return res.status(404).json({ error: 'Script not found' });
  }
  res.json(scripts[name]);
});

// Create / Update script
app.post('/api/scripts', requireAuth, (req, res) => {
  let { name, content } = req.body;

  if (!name || typeof name !== 'string') {
    return res.status(400).json({ error: 'Name is required' });
  }

  // Sanitize name → only a-z 0-9 - _
  name = name.toLowerCase().trim().replace(/[^a-z0-9\-_]/g, '').slice(0, 64);
  if (!name) {
    return res.status(400).json({ error: 'Invalid name (use letters, numbers, - or _)' });
  }

  if (typeof content !== 'string') {
    return res.status(400).json({ error: 'Content is required' });
  }

  // Limit size (2 MB)
  if (content.length > 2 * 1024 * 1024) {
    return res.status(400).json({ error: 'Script too large (max 2 MB)' });
  }

  const isUpdate = !!scripts[name];
  scripts[name] = {
    id: scripts[name]?.id || uuidv4(),
    name,
    content,
    updated: new Date().toISOString()
  };

  saveScripts(scripts);

  res.json({
    success: true,
    message: isUpdate ? 'Script updated' : 'Script created',
    name,
    rawUrl: `/raw/${name}`
  });
});

// Delete script
app.delete('/api/scripts/:name', requireAuth, (req, res) => {
  const name = req.params.name.toLowerCase();
  if (!scripts[name]) {
    return res.status(404).json({ error: 'Script not found' });
  }
  delete scripts[name];
  saveScripts(scripts);
  res.json({ success: true });
});

// Catch-all → 404 (hides the fact that a real site exists)
app.use((req, res) => {
  res.status(404).type('text/plain').send('404 Not Found');
});

app.listen(PORT, () => {
  console.log(`Lua Host running on port ${PORT}`);
  console.log(`Dashboard password is set (check server.js)`);
});
